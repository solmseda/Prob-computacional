#######
# 1)
#######

set.seed(123)

nsamples <- 1000
vitorias <- c(0, 0, 0) # A, B, C

vencedorDuelo <- function(p1, p2) {
  if ((p1 == 1) & (p2 == 2)) {
    prob <- 0.60
  } else if ((p1 == 2) & (p2 == 1)) {
    prob <- 0.40
  } else if ((p1 == 2) & (p2 == 3)) {
    prob <- 0.65
  } else if ((p1 == 3) & (p2 == 2)) {
    prob <- 0.35
  } else if ((p1 == 3) & (p2 == 1)) {
    prob <- 0.55
  } else if ((p1 == 1) & (p2 == 3)) {
    prob <- 0.45
  }
  
  if (runif(1) < prob) {
    return(p1)
  } else {
    return(p2)
  }
}

for (i in 1:nsamples) {
  descanso <- sample(c(1, 2, 3), size = 1, prob = c(0.4, 0.3, 0.3))
  
  if (descanso == 1) {
    p1 <- 2
    p2 <- 3
  } else if (descanso == 2) {
    p1 <- 1
    p2 <- 3
  } else {
    p1 <- 1
    p2 <- 2
  }
  
  vencedor1 <- vencedorDuelo(p1, p2)
  vencedor2 <- vencedorDuelo(vencedor1, descanso)
  
  vitorias[vencedor2] <- vitorias[vencedor2] + 1
}

probabilidades <- (vitorias / nsamples)
sprintf("Probabilidade de vitoria:")
sprintf("A = %.2f.", probabilidades[1])
sprintf("B = %.2f.", probabilidades[2])
sprintf("C = %.2f.", probabilidades[3])

#######
# 2)
#######

set.seed(123)

# Parâmetros
n_dias <- 100
voos_por_dia <- 20
n_voos <- n_dias * voos_por_dia
capacidade <- 180
passagens_vendidas <- 190
taxa_voluntarios <- 0.25
comp_voluntaria <- 1000
comp_forcada <- 2500

# Pré-alocação dos vetores
presentes_total <- numeric(n_voos)
realocados_embarcados <- numeric(n_voos)
novos_embarcados <- numeric(n_voos)
excedentes <- numeric(n_voos)
voluntarios <- numeric(n_voos)
forcados <- numeric(n_voos)
custos <- numeric(n_voos)
overbooking <- logical(n_voos)

# Fila de espera inicial
fila <- 0

for (voo in 1:n_voos) {
  # Sorteio de presença
  probs <- runif(passagens_vendidas, 0.90, 0.95)
  presentes_novos <- sum(runif(passagens_vendidas) < probs)
  
  total_presentes <- fila + presentes_novos
  presentes_total[voo] <- total_presentes
  
  if (total_presentes > capacidade) {
    assentos_disponiveis <- capacidade
    realocados_embarcados[voo] <- min(fila, assentos_disponiveis) # fila
    assentos_restantes <- assentos_disponiveis - realocados_embarcados[voo]
    
    novos_embarcados[voo] <- min(presentes_novos, assentos_restantes)
    excedentes[voo] <- presentes_novos - novos_embarcados[voo]
    
    voluntarios[voo] <- floor(excedentes[voo] * taxa_voluntarios)
    forcados[voo] <- excedentes[voo] - voluntarios[voo]
    
    custos[voo] <- voluntarios[voo] * comp_voluntaria + forcados[voo] * comp_forcada
    fila <- voluntarios[voo] + forcados[voo] # Excedentes
    
    overbooking[voo] <- TRUE
  } else {
    realocados_embarcados[voo] <- fila
    novos_embarcados[voo] <- presentes_novos
    excedentes[voo] <- 0
    voluntarios[voo] <- 0
    forcados[voo] <- 0
    custos[voo] <- 0
    fila <- 0
    overbooking[voo] <- FALSE
  }
  
}

# Estatísticas
sprintf("Resultados da Simulação:")
sprintf("Taxa média de overbooking: %.2f%%", mean(overbooking) * 100)
sprintf("Média de passageiros presentes por voo: %.2f", mean(presentes_total))
sprintf("Total de excedentes: %d", sum(excedentes))
sprintf("Total de voluntários realocados: %d", sum(voluntarios))
sprintf("Total de forçados realocados: %d", sum(forcados))
sprintf("Custo total com compensações: R$ %.2f", sum(custos))
sprintf("Custo médio diário: R$ %.2f", sum(custos) / n_dias)
